/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game.design.pkg1;

import java.awt.Canvas;

/**
 *
 * @author Ghomez
 */
public class Game extends Canvas {

    
    
    /**Attributes*/
    
    /**TITLE variable of Game*/
    static String TITLE = "Game Design 1";
    
    /**version variable of Game*/
    static String version = "v0.0.0";
    
    /**Links*/
    
    /**Constructor*/
    
    public Game(){
        System.out.println("Game: New Game created");
        
    }
    
    /**Public Protocol*/
    
    
}
